################################################################
##             绝对禁止删除和修改此README.txt文件！           ##
##Modifying or Deleting this README.txt is STRICTLY FORBIDDEN.##
################################################################

*~ 鸣谢 - Credits ~*

(按首字母排序 In alphabetical order)

Freesound用户名 - 用于音效
Freesound ID - Her sound(s) used to make...
11linda - hit1, hit2 sounds
drotzruhn - all of 3 "eat" sounds, drink, and burp.
silversatyr - hit3 sounds

依据Freesound.org网站此页面上的说明(https://freesound.org/help/faq/#licenses)，
由于所有用于本资源包的声音样本都来自Freesound.org，且适用其“Attribution”协议，
所有声音样本的原作者ID与网址皆列举如下。
According to this page(https://freesound.org/help/faq/#licenses),
All sounds in this pack is made from samples provided by Freesound.org,
under the "attribution" license.  
I have listed all of their original creators' IDs and sound URLs below. 

* pain: ouch by 11linda | License: Attribution
https://freesound.org/people/11linda/sounds/234039/

* eating cracker.wav by drotzruhn | License: Attribution
https://freesound.org/people/drotzruhn/sounds/405325/
* eating tomato.wav by drotzruhn | License: Attribution
https://freesound.org/people/drotzruhn/sounds/405327/
* drinking.wav by drotzruhn | License: Attribution
https://freesound.org/people/drotzruhn/sounds/405324/

* Woman in Pain 2.ogg by silversatyr | License: Attribution
https://freesound.org/people/silversatyr/sounds/333279/